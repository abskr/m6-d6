CREATE TABLE IF NOT EXISTS
    	students(
        	student_id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
            name VARCHAR(50) NOT NULL,
          	last_name VARCHAR(50) NOT NULL,
            country VARCHAR(50) NOT NULL
        );
        
 INSERT INTO
	students(
      name,
      last_name,
      country
    )
    VALUES (
      'Gentrit',
      'Begaj',
      'Turkey'
    );
    
INSERT INTO
	students(
      name,
      last_name,
      country
    )
    VALUES (
      'Slavko',
      'Josipovic',
      'Turkey'
    );
    
INSERT INTO
	students(
      name,
      last_name,
      country
    )
    VALUES (
      'Luca',
      'Perullo',
      'Turkey'
    );
    
    
INSERT INTO
	students(
      name,
      last_name,
      country
    )
    VALUES (
      'Ardi',
      'Germenji',
      'Turkey'
    );
    
    
     INSERT INTO
	students(
      name,
      last_name,
      country
    )
    VALUES (
      'Jamie',
      'Ellis',
      'Turkey'
    );
    
INSERT INTO
	students(
      name,
      last_name,
      country
    )
    VALUES (
      'Hüseyin Can',
      'Soylu',
      'Turkey'
    );
    
INSERT INTO
	students(
      name,
      last_name,
      country
    )
    VALUES (
      'Hafiz',
      'Ali',
      'Turkey'
    );
     
 INSERT INTO
	students(
      name,
      last_name,
      country
    )
    VALUES (
      'Juan',
      'Arana',
      'Turkey'
    );
    
INSERT INTO
	students(
      name,
      last_name,
      country
    )
    VALUES (
      'Mihai',
      'Ivanov',
      'Turkey'
    );
       
INSERT INTO
	students(
      name,
      last_name,
      country
    )
    VALUES (
      'David',
      'Zapata',
      'Turkey'
    );
    
INSERT INTO
	students(
      name,
      last_name,
      country
    )
    VALUES (
      'Paul',
      'Balu',
      'Turkey'
    );
    
INSERT INTO
	students(
      name,
      last_name,
      country
    )
    VALUES (
      'Sean',
      'Knowles',
      'Turkey'
    );